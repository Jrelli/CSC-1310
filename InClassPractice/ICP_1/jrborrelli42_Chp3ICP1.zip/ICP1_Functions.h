/*
	Title:      ICP1_Functions.h
	Author:     Joey Borrelli
	Date:       1/27/2024
	Purpose:    This program goes bee do bee bop. 
*/

#ifndef ICP1_FUNCTIONS_H
#define ICP1_FUNCTIONS_H
using namespace std;

// Constant declaration

// Structure declaration

// Function declaration
int sumOfArray(int[], int);

#endif